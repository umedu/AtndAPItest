package adt.atnd.umedu;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	ListView list;
	TextView ver;
	TextView name;
	TextView api;
	Button Btngetdata;
	ArrayList<HashMap<String, String>> oslist = new ArrayList<HashMap<String, String>>();
	JSONObject json;
	// URL to get JSON Array
	private static String url = "http://api.atnd.org/eventatnd/event/?count=50&format=json";


	// JSON Node Names
	private static final String TAG_EVENTS = "events";
	private static final String TAG_EVENT = "event";
	private static final String TAG_TITLE = "title";
	private static final String TAG_STARTED_AT = "started_at";
	private static final String TAG_ENDED_AT = "ended_at";
	private static final String TAG_PLACE = "place";

	JSONArray android = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);
		oslist = new ArrayList<HashMap<String, String>>();

		Btngetdata = (Button) findViewById(R.id.getdata);
		Btngetdata.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View view) {
				new JSONParse().execute();

			}
		});

	}
	String getFormatDate(String paramString)
	  {
	    if (paramString.equals("null")) {
	      return "-";
	    }
	    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
	    Date localDate1;
		try
	    {
	      Date localDate2 = localSimpleDateFormat.parse(paramString);
	      localDate1 = localDate2;
	    }
	    catch (ParseException localParseException)
	    {
	      for (;;)
	      {
	        localParseException.printStackTrace();
	         localDate1 = null;
	      }
	    }
	    localSimpleDateFormat.applyPattern("yyyy/MM/dd(E) HH:mm");
	    return localSimpleDateFormat.format(localDate1);
	  }
	private class JSONParse extends AsyncTask<String, String, JSONObject> {
		private ProgressDialog pDialog;
		private JSONArray categories;
		private JSONArray category;


		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			ver = (TextView) findViewById(R.id.vers);
			name = (TextView) findViewById(R.id.name);
			api = (TextView) findViewById(R.id.api);
			pDialog = new ProgressDialog(MainActivity.this);
			pDialog.setMessage("Getting Data ...");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(true);
			pDialog.show();

		}

		@Override
		protected JSONObject doInBackground(String... args) {

			JSONParser jParser = new JSONParser();

			json = jParser.getJSONFromUrl(url);
			return json;
		}

		@Override
		protected void onPostExecute(JSONObject json) {
			pDialog.dismiss();
			try {
				Log.d("json", json.toString());

//				  try {
//			            JSONObject rootObject = new JSONObject(json);
//			        	   JSONObject bodyObject = rootObject.getJSONObject("Body");
//			            JSONObject booksbooksearchObject = bodyObject.getJSONObject("BooksBookSearch");
//			            JSONObject itemsObject = booksbooksearchObject.getJSONObject("Items");
//			            JSONArray  itemArray = itemsObject.getJSONArray("Item");
//
//			            int count = itemArray.length();
//
//			            JSONObject[] bookObject = new JSONObject[count];
//
//			            for (int i=0; i<count; i++){
//			            	bookObject[i] = itemArray.getJSONObject(i);
//			            }
				/**
				 * add parce1
				 */
				JSONArray localJSONArray = json.getJSONArray("events");
				JSONObject localJSONArray2 = localJSONArray.getJSONObject(0);
				JSONArray localJSONArray3 = localJSONArray2.getJSONArray("event");
				Log.d("localJSONArray3", ""+localJSONArray3);
				
			    int o =  json.getInt("results_available");

				JSONObject[] arrayOfJSONObject = new JSONObject[o];
				
				Log.d("results_available", ""+o);
				
				
				for (int j = 0; j < localJSONArray3.length(); j++) {
				
				arrayOfJSONObject[j] = localJSONArray3.getJSONObject(j);
		       // j++;
				//}
				Log.d("arrayOfJSONObject", ""+arrayOfJSONObject);
				HashMap<String, String> localHashMap = new HashMap<String, String>();
				
				
		         // int j = 0;
		          localHashMap.put("event_id", arrayOfJSONObject[j].getString("event_id"));
		          localHashMap.put("title", arrayOfJSONObject[j].getString("title"));
		          localHashMap.put("catch", arrayOfJSONObject[j].getString("catch"));
		          localHashMap.put("started_at", getFormatDate(arrayOfJSONObject[j].getString("started_at")));
		          localHashMap.put("ended_at", getFormatDate(arrayOfJSONObject[j].getString("ended_at")));
		          localHashMap.put("place", arrayOfJSONObject[j].getString("place"));
		          oslist.add(localHashMap);
		          j++;
		          Log.d("localHashMap", ""+localHashMap);
				}
		          list = (ListView) findViewById(R.id.list);

					ListAdapter adapter = new SimpleAdapter(
							MainActivity.this, oslist, R.layout.list_v,
							new String[] { TAG_TITLE, TAG_STARTED_AT,
									TAG_PLACE }, new int[] { R.id.vers,
									R.id.name, R.id.api });

					list.setAdapter(adapter);
/*
				// Getting JSON Array from URL
				categories = json.getJSONArray(TAG_EVENTS);
				for (int i = 0; i < categories.length(); i++) {
					JSONObject a = categories.getJSONObject(i);
					String check = a.getString(TAG_EVENTS);
					Log.d("check", check);
					android = json.getJSONArray("");
					for (int i1 = 0; i1 < android.length(); i1++) {
						JSONObject c = android.getJSONObject(i1);

						// Storing JSON item in a Variable
						String ver = c.getString(TAG_TITLE);
						String name = c.getString(TAG_STARTED_AT);
						String api = c.getString(TAG_PLACE);

						// Adding value HashMap key => value

						HashMap<String, String> map = new HashMap<String, String>();

						map.put(TAG_TITLE, ver);
						map.put(TAG_STARTED_AT, name);
						map.put(TAG_PLACE, api);

						oslist.add(map);
						list = (ListView) findViewById(R.id.list);

						ListAdapter adapter = new SimpleAdapter(
								MainActivity.this, oslist, R.layout.list_v,
								new String[] { TAG_TITLE, TAG_STARTED_AT,
										TAG_PLACE }, new int[] { R.id.vers,
										R.id.name, R.id.api });

						list.setAdapter(adapter);*/
						list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

							@Override
							public void onItemClick(AdapterView<?> parent,
									View view, int position, long id) {
								Toast.makeText(
										MainActivity.this,
										"You Clicked at "
												+ oslist.get(+position).get(
														"name"),
										Toast.LENGTH_SHORT).show();

							}
						});

					//}
				//}
			} catch (JSONException e) {
				e.printStackTrace();
			}

		}
	}

}
