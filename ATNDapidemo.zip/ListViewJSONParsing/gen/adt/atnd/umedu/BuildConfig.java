/** Automatically generated file. DO NOT MODIFY */
package adt.atnd.umedu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}